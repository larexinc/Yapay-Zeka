const users = [
  {name: "Ayşe", bio: "Kitap okumayı sever", img: "https://randomuser.me/api/portraits/women/1.jpg"},
  {name: "Fatma", bio: "Kedi aşığı", img: "https://randomuser.me/api/portraits/women/2.jpg"},
  {name: "Ahmet", bio: "Spor ve doğa", img: "https://randomuser.me/api/portraits/men/3.jpg"},
  {name: "Mehmet", bio: "Film tutkunu", img: "https://randomuser.me/api/portraits/men/4.jpg"}
];

let currentIndex = 0;

function showUser(index) {
  if(index >= users.length) {
    document.getElementById("userCard").innerHTML = "<h2>Kimse kalmadı 😢</h2>";
    document.querySelector(".buttons").style.display = "none";
    return;
  }
  const user = users[index];
  document.getElementById("userImg").src = user.img;
  document.getElementById("userName").innerText = user.name;
  document.getElementById("userBio").innerText = user.bio;
}

document.getElementById("likeBtn").addEventListener("click", () => {
  alert(`❤️ ${users[currentIndex].name} beğenildi!`);
  currentIndex++;
  showUser(currentIndex);
});

document.getElementById("dislikeBtn").addEventListener("click", () => {
  alert(`❌ ${users[currentIndex].name} geçildi!`);
  currentIndex++;
  showUser(currentIndex);
});

showUser(currentIndex);
